#in day 14 we are learn about if_else statement......
#first program in if else............
a=int(input("enter your age :"))
print("your age is :", a)

if(a>18):
    print("you can drive")

else:
    print("you can not drive")
#second proram in if else .......    
num=-9
if(num<0):
    print("number is nagetive")

elif(num==0):
    print("number is 0")
else:
    print("number is positive")  

#third program in if else ... 
     