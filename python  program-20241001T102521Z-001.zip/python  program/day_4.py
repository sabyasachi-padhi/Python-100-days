# our first python program..........
print("jai sri Ram")
print("jai Hanuman")
print(23+23)

