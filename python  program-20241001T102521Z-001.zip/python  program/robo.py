import pyttsx3

speaker=pyttsx3.init()

while True:
 text=input("enter text here: ")
 if(text=="quit"):
    break
 speaker.say(text)
 speaker.runAndWait()

    