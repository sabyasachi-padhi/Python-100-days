#in day 22 we are learn about list data type.....

# L=["tarinee" , "deba" , "miku"]
# print(L)

list_1=["tarinee"  , 23 , 2.4 , True, 3 , 5 , 7, False ]
#print(list_1)

# print(type(L))

# #printing all element of the list.....
# print(L[0])
# print(L[1])
# print(L[2])

# in keyword is used to evaluate if the given element is present in the string or not......... 
# if 23 in list_1:
#     print("yes")

#print(list_1[0:-3])#len(list_1) - 3........\

print(list_1)

print(list_1[0:6:2])#in this line 2 is jump index.......


lst=[i for i in range(10) if i%2==0]# this is callaed list Comprehension........ with condition......
print(lst)

print(list_1[-2])