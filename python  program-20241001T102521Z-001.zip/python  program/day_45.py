#in day 45 we are learn about if __name__="__main__" and why we are use this

import harry

harry.wellcom()