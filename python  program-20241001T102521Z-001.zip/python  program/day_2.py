#in day two that we are learn some amazing python program
# 1.jarves virtual comaand program like Tony_stark in iron_man.
# 2.Love calculater .
# 3.face recognation program.
# 4.flapy bird program .
# 5.snake game in python.