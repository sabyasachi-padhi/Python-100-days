import turtle as tur
tur.bgcolor("black")

squary=tur.Turtle()
squary.speed(20)
squary.pencolor("green")
for i in range(800):
    squary.forward(i)
    squary.left(91)