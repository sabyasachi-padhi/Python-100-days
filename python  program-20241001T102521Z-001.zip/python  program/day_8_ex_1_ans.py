" " " excersize_1 crate calculater capbale of performing substraction , addition , multiplication , and division opration on two number  " " "

a=input("enter the first number :")
b=input("enter the second number :")
print("..............................................")
print("result for addition :", int(a)+int(b))
print("result for subtraction :", int(a)-int(b))
print("result for multiplication :", int(a)*int(b))
print("result for division :", int(a)/int(b))