#in day 6 we are learn about varibale and data_type......

a=1#-->int data_type
b=True#--->boolean data_type
c="harry"#-->string data_type
d=3.4#---->flot data_type
l=[1, "tarinee", 5.6, True]#--->list data_type
t=(1,4, 5 , "daba" , False)#--->tuple data_type
dic={"name":"tarinee" , "age" : 20 , "canvote" :True}#-->dictionary datra_type.......
print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(l))
print(type(dic))


