#in day 34 we are learn about for loop with else in python....
# for i in range(7):
#     print(i)

# else:
#     print("sorry no i")
    
#with the while loopa
i=0
while i < 7:
    print(i)
    i=i+1

else:
    print("sorry no i")    