#in day 17 we are learn about for loop...........
# itrating over a string...
name='tarinee'
for i in name:
    print(i , end=",")

#................................
#itrating over a list:
# colors=["red" , "green" , "blue" , "yellow"]

# for i in colors:
#     print(i)

#.............................................
# for i in range(1,21):
#     print(i)
# for i in range(50):
#     print(i)
