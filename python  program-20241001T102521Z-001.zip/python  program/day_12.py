#in day 12 we are learn about string slicing and opraetion on string
name="harry , shubham"
print(name[0:5])
print(len(name))
other_name="harry"
print(other_name[0:4])
print(other_name[:4])#python automaticaly add 0 in it......
print(name[:])#python automaticaly put len of name
print(other_name[0:-3])#python automaticaly put len of name - 3 mean 0:2....
 
