#in day 81 we are learn about hybrid inheritance and heirarchical inheritance in python.

#this is an example of hybrid inheritance.....
# class Baseclass:
#     pass

# class Derived_class1(Baseclass):
#     pass

# class Derived_class2(Baseclass):
#     pass

# #till now this is an single inheritance....

# class Derived_class3(Derived_class1 , Derived_class2):
#     pass

#this is a multiple inheritance.......

#this is an example of heirarchical inharitance........
#when we have multiple child class and one parent class.....
class Base_class:
    pass
class D1(Base_class):
    pass

class D2(Base_class):
    pass




