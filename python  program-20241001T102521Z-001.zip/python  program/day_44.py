#in day 44 we are learn about how import work
#import is used to fetch content from module and other file
# import harry as h

# h.wellcom()

#import math as m 
#we can use as keyword if the module name is big
#now we can see how we can  import sqrt function from  math using from keyword


from math import sqrt as s

num=3

ans=s(num)

print(ans)