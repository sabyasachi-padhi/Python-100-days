# in day 10 we are learn how to take user input in python
#using input() function we are take user input

name=input("enter your name :")
number=int(input("enter your driving laicence number :"))
print("your name is :" , name)
print("your laicence number is :" , number)

