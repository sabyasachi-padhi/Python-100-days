#in day 23 we are learn about list methods...........
l=[11 ,  3 ,  8 , 8, 8 , 4  , 23, 10, 34]
#print(l)
#l.append(7)#append method used insert an element at the end of the list
#print(l)


#l.sort()#sort method is used to sort the unsorted list
#print(l)

#l.sort(reverse=True)#if you can make the reverse is equle to True then the list is sort in assending.....
#print(l)

#l.reverse()#reverse method is use to revesrse the string......
#print(l)


#print(l.index(23))#index method is give the  first occurance of given element...

#print(l.count(8))#count method return the number of occurance of the given element....

#m=l.copy()# this method is used to copy the list in to other list...
#m[0]=0
#print(l)

# l.insert(3 , 67)# this method is used to insert the given element at given index.....
# print(l)

m=[567, 78, 89]
l.extend(m)#this method is used to add another list element to the exsisting list at the end of the list....
print(l)

















