#in day 31 we are learn about set in python.....
#set does not allows  duplicate element.......
#in set everything is same as list except in set duplicate element in not allowed.....
#set is a un-ordered list.....
s={2 , 4 , 5 , 6 , 7}
set_2={True ,  "string" , 5 , 6.7 , False , 5 , 6.7}
print(set_2)
print(s) 

# harry={}#if you write this then the type is dictionary
# print(type(harry))

#if you want to create an empty set then you can write....
harry=set()
print(type(harry))

#print value of set:
for i in s:
    print(i)