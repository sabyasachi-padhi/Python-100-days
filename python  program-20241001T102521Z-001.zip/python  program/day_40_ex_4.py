#in day 40 we are doing an excersize.......


#SECRET CODE LANGUAGE.......
#..........................................................
#write a pyhton program to translate a message in to secrate code language. use the rules below to translate the normal  english into secret code languge..

#coding the message..
#if : the word contain atleast 3 charecter remove the first letter and append it at the end.
#now append three random charecter at the starting and the end

#else:
   #simply reverse the string..


#Decoding the message......
#if the word contains less than 3 charecters , reverse it

#else:
   #remove 3 random charecters from start and end .now remove the last letter and appen it to the beginning

#your program should ask whether you want to code ar decode....   

   
