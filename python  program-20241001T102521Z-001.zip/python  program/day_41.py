#in day 41 we are learn about short hand if else statement......
a=330
b=3303
print("A") if a > b else print("=")if a==b else print("B")
