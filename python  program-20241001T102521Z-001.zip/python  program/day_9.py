#in day 9 we are learn Typecasting in python
#type_casting is two type...
# 1.explicit_typecasting...
string="15"
number=7

string_number=int(string)

sum=number+string_number

print("the sum of both the number is :" , sum)

# 2.implicit _typecasting...
print(type(string))

