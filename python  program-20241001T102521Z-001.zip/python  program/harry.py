def wellcom():
    print("wellcom harry")
print(__name__)
if __name__=="__main__":
    wellcom()    