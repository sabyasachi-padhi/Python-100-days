#in day 18 we are learn about while loop.....
# count=5
# while(count > 0):
#     print(count)

#     count=count-1

i=0
while(i<3):
    print(i)
    i=i+1