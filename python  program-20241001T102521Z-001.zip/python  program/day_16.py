#in dy 16 we are learn about match case .......
#match case is just like switch case in other language.......

# x=int(input("enter the value of x : "))

# match x:

#     case 0:

#         print("x is zero")

#     case 4:
#         print("case is 4")

#     case _:#this case is a defult case...
#         print(x)   
# 
# we also use case with if just like case_ if x!=90:     