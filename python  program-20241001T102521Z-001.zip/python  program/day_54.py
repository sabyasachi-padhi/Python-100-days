#in day 54 we are learn about 'is' vs '==' in python...
#is and == keyword both are comparsion opretor......
#is-->compare exact location of object in memory.
#==--->compare values....

#for the constant and immuatable object are same then 'is' and '==' both are true...... 

# a=[1,2,3]
# b=[1,2,3]

a=4
b=4

print(a is b)
print(a == b)