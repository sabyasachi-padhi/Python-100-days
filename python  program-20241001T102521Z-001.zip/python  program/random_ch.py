import random as r
import string

ran=r.choice(string.ascii_letters)
print(ran)