#in day 11 we are learn about string ................
#string are immutable means we are not doing any changes....

#string intialization.........
name="tarinee"
friend="deba"
another_friend="sohel"

for ch in name:
    print(ch)

#print("hallo ," + name)

# sir="harry"
# print(name)

# print(name[0])

# print(name[0:4])# incluede 0 index but not inlcude 4 index only print 0 to 3

# print(len(name))


# print(name[0:-3])


#quick quize
print(name[-4:-2])
# output : in

