#in day 56 we are learn about OBJECT ORIENTED PROGRAMMING

#programming is two type:
#1.procedural programming
#2.object oriented programming...

#Railwayform ---> class[blue print]
#harry -->harry ki info wal form --->object[entity]
#shubam -->shubam ki info wal form --->object[entity]
#trinee -->tarinee ki info wal form --->object[entity]

