#in day 52 we are learn about lambda function........

#with out lambda function.......
# def sqrt(x):
#     return x*x

# print(sqrt(3)) 

#for using lambda function.........
sqrt=lambda x :x*x
avg=lambda x ,y :(x+y)/2
print(avg(3,4))


