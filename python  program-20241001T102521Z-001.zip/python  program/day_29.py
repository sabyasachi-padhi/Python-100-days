#in day 29 we are learn about docstring.......and PEP_8
#docstring gives the brife idea about function , class , method or module
def square(n):
    '''Takes in a number n , return the square of n'''
    print(n**2)

square(4)
print(square.__doc__)#for using this that we can print docstring

#PEP-8 is a guide-line
#PEP-8 full form = Python Enhancment proposal.....

#THE ZEN OF PYTHON......
 
    